<?

###loading ... default option & language
if(!$_REQUEST['op']) $_REQUEST['op'] = 'start';
if(!$_SESSION['web']['lang']) $_SESSION['web']['lang'] = 'english';
if($_REQUEST['lang']) $_SESSION['web']['lang'] = $_REQUEST['lang'];

###loading ... language
require_once('install/lang/'.$_SESSION['web']['lang'].'.php');

Function assoc_opt2($array,$value){
	foreach($array as $ky=>$vl){
		$return .= '<option value="'.$ky.'"';
		if($ky==$value) $return .= ' selected';
		$return .= '>'.$vl.'</option>';
	}
	return $return;
}

Function array_opt2($array,$value){
	foreach($array as $vl){
		$return .= '<option';
		if($vl==$value) $return .= ' selected';
		$return .= '>'.$vl.'</option>';
	}
	return $return;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="<?=XML_LANG?>" xml:lang="<?=XML_LANG?>">
<head>
	<title>KMleague</title>
	<meta http-equiv="content-type" content="text/html; charset=<?=ENCODING?>" />
	<meta name="Robots" content="index, follow, all" />
	<meta name="Revisit-After" content="1 days" />
	<meta name="Author" content="Krystian Zbikowski - KMprojekt" />
	<link rel="stylesheet" href="install/install.css" type="text/css" />
</head>
<body>

<div id="mainBody">
<div id="banner"><div id="flaga"><?
if($_SESSION['web']['lang'] == 'english') $flag = 'polski'; else $flag = 'english';
print('<a href="'.$_SERVER['PHP_SELF'].'?lang='.$flag.'&amp;op='.$_REQUEST['op'].'"><img alt="flaga" src="install/im/lang_'.$flag.'.gif"/> '.$flag.'</a>');
?></div><img style="float: right;" alt="logo" src="install/im/logo.gif"/></div>
<div id="menu"><?

//feature options
//$options = array('start', 'install', 'update', 'import');
$options = array('start', 'install');

foreach($options as $vl) print('<a href="install.php?lang='.$_SESSION['web']['lang'].'&amp;op='.$vl.'">'.$lang[$vl].'</a>');

?></div>
<div id="content">
<?

	$read = 'install/data/'.$_REQUEST['op'].'_'.$_SESSION['web']['lang'].'.html';
	$req = 'install/data/'.$_REQUEST['op'].'_'.$_SESSION['web']['lang'].'.php';
	if(in_array($_REQUEST['op'],$options)){
		if($_REQUEST['op']=='install'){
			if(!$_REQUEST['step']) $_REQUEST['step'] = 1;
			#wykonywanie funkcji
			if(!$_POST['bk'] && !$_POST['skip']){
				$priv = '0'.$_POST['prival'];
				$fdir = array('_avatars', '_clan_logo', '_inc/config.php', 'awards', 'data', 'demos', 'screen', 'tmp_screen');
				print('<div class="head1">'.$lang[$_REQUEST['op']].': '.$lang['istep_'.($_REQUEST['step']-1)].' ['.($_REQUEST['step']-1).'/4]</div>');
				switch($_REQUEST['step']){
					case 1:{
						foreach($fdir as $vl){
							if(!is_writable($vl)){
								if($critical!=1) print($lang['step_er1']);
								$critical = 1;
								print($vl.'<br/>');
							}
						}
						if($critical==1) print('<div class="bold">'.$lang['step_er12'].'</div>'); else print($lang['step_ok1']);
						break;
					}
					case 2:{
						$db = @mysql_connect($_POST['server'],$_POST['login'],$_POST['passw']);
						if($db) $bd = @mysql_select_db($_POST['dbase']);
						if($bd){
							//import information to database
							$db_sqls = 'install/db1_4.sql';
							if(file_exists($db_sqls)){
								$sql = file($db_sqls);
								foreach($sql as $qry){
									$qry = str_replace('{{prefix}}', $_POST['prefix'], $qry);
									if(!mysql_query($qry)){ $critical = 1; echo $qry.':'.mysql_error().'<br/>'."\n";}
								}
								print($lang['step_ok2'].'<br/>');
								if($critical == 1) print($lang['step_er22']); else print($lang['step_ok22']);
							}else print($lang['step_er23']);
						}else{
							print($lang['step_er2']);
							$critical = 1;
						}
						break;
					}
					case 3:{
						$db = @mysql_connect($_POST['server'],$_POST['login'],$_POST['passw']);
						if($db) $bd = @mysql_select_db($_POST['dbase']);
						#create configuration file and add league to database
$fdata = "<?
define(KML_DB_HOST, '".$_POST['server']."');
define(KML_DB_USER, '".$_POST['login']."');
define(KML_DB_PASSW, '".$_POST['passw']."');
define(KML_DB_NAME, '".$_POST['dbase']."');
#cookie main address
define(KML_COOKIES, '".$_POST['cookies']."');
#maximum avatar size
define(KML_AVATAR_SIZE, '20048');
#maximum avatar resolution width:height (60:60 as default)
define(KML_AVATAR_RES, '60:60');
#admin e-mail (ie. shown in mails for new registered users)
define(KML_ADMIN_MAIL, '".$_POST['website_email']."');
#authorization of accounts(on, off)
define(KML_ACCOUNT_AUTH, '".$_POST['accounts_auth']."');
#turn on/off registration
define(KML_REGISTRATION, 1);
#chmod which allow league script to remove files on server
define(KML_CHMOD, ".$priv.");
#multi dirs Y-yes,N-no (if you want multi leagues be set up in different dirs set it to Y), no to display leagues list on website and switch through it
define(KML_MULTI_DIRS, 'N');
#tables prefix
define(KML_PREFIX, '".$_POST['prefix']."');
#default league id (set 0 if you have default page), use it just if you have KML_MULTI_LEAGUES set N
define(KML_DEFAULT_LEAGUE, 1);
#number of days to clean password change and accounts before authorization
define(KML_CLEAN_REG_PAS, 3);
\n?>
";
//<?
						$lnk = fopen('_inc/config.php', 'w+');
						fwrite($lnk,$fdata);
						fclose($lnk);
						if($_POST['forum']=='-') $_POST['forum'] = '';
						$qry = 'INSERT INTO `'.$_POST['prefix'].'_config` (league, signup, signup_dlimit, signup_tlimit, match_per_sgroup, country, name, irc_server, max_players, max_matches, transfers, walkover, user_clans, block_ident, dispute_limit_before, dispute_limit_after, work_name, visible, default_lang, main_id, wars_id, roster_id, article_id, address, skin, league_type, score, score_details, player_type, poll_live_time, news_limit_show, short_latest_news, short_latest_matches, user_news, no_flags, forum, forum_prefix, meta_keywords) VALUES(1, "D", 0, 0, 0, 51, "'.$_POST['lname'].'", "'.$_POST['irc'].'", 0, 0, "Y", "M", "N", "N", 0, 0, "'.$_POST['lname'].'", "Y", "'.$_POST['default_lang'].'", 1, 2, 3, 4, "'.$_POST['website'].'", "skin/default/", "'.$_POST['ltype'].'", "'.$_POST['score'].'", "N", "T", "2", "5", "8", "6", "N", "0", "'.$_POST['forum'].'", "'.$_POST['forum_prefix'].'", "");';
						if(!mysql_query($qry)) $critical = 1;
						//create season
						$qry = 'INSERT INTO `'.$_POST['prefix'].'_season`(league, sname, descr) VALUES(1, "1st", "1st")';
						if(!mysql_query($qry)) $critical = 1;
						//create menu
						if($_POST['ltype']=='D') $status_pstats = 'N'; else $status_pstats = 'Y';
						if($_POST['forum_web']) $forum_menu = ", (1, 'Y', 0, 0, '', 'forum', '".$_POST['forum_web']."', 'N', 'N', 0, 12)";
						$qry = "INSERT INTO `".$_POST['prefix']."_menu`(league, visible, privilages_global, privilages_local, head, head_lang, `link`, `target`, `local`, `column`, `row`) VALUES(1, 'Y', 0, 0, '', 'news', 'index.php?op=news', 'S', 'Y', 0, 1),(1, 'Y', 0, 0, '', 'rules', 'index.php?op=rules', 'S', 'Y', 0, 2),(1, 'Y', 1, 0, '', 'sign', 'index.php?op=sign', 'S', 'Y', 0, 4),(1, 'Y', 0, 0, '', 'clans', 'index.php?op=clans', 'S', 'Y', 0, 3),(1, 'Y', 0, 0, '', 'awards', 'index.php?op=awards', 'S', 'Y', 0, 5),(1, 'Y', 0, 0, '', 'schedule', 'index.php?op=schedule', 'S', 'Y', 0, 6),(1, 'Y', 0, 0, '', 'all_matches', 'index.php?op=all_matches', 'S', 'Y', 0, 8), (1, 'Y', 0, 0, '', 'cls_stats', 'index.php?op=cstats', 'S', 'Y', 0, 7), (1, '".$status_pstats."', 0, 0, '', 'pls_stats', 'index.php?op=pstats', 'S', 'Y', 0, 9), (1, 'Y', 0, 0, '', 'lg_stats', 'index.php?op=lstats', 'S', 'Y', 0, 10), (1, 'Y', 0, 0, '', 'special_table', 'index.php?op=special_table', 'S', 'Y', 0, 11), (1, 'Y', 0, 0, '', 'interviews', 'index.php?op=inter', 'S', 'Y', 0, 14), (1, 'Y', 0, 0, '', 'polls', 'index.php?op=polls', 'S', 'Y', 0, 13), (1, 'Y', 0, 0, '', 'admin_team', 'index.php?op=crew', 'S', 'Y', 0, 15), (1, 'Y', 0, 0, '', 'users', 'index.php?op=users', 'S', 'Y', 0, 16)".$forum_menu.";";
						if(!mysql_query($qry)) $critical = 1;
						if($critical==1) print($lang['step_er3']); else print($lang['step_ok3']);
						break;
					}
					case 4:{
						require_once('_inc/config.php');
						require_once('_inc/dbcon.php');
						require_once('_inc/oth_func.php');
						require_once('_inc/reg_forum.php');
						$qry = 'INSERT INTO '.KML_PREFIX.'_users(iduser, login, pass, mail, `grants`, added, show_mail) VALUES(5, "'.$_POST['na_login'].'", "'.md5($_POST['na_passw']).'", "'.$_POST['na_email'].'", 4, '.time().', "N"), (1, "bot", "'.md5(time()).'", "'.KML_ADMIN_MAIL.'", "0", "'.time().'", "N")';
						if(!mysql_query($qry)) $critical = 1;
						if($critical!=1){
							reg_forum(5);
						}
						if($critical==1) print($lang['step_er4']); else print($lang['step_ok4']);
					}
				}
				print('<br/><br/>');
			}
			if(($critical!=1 && !$_POST['bk']) || $_REQUEST['step']==1) $stepH = $_REQUEST['step']; else $stepH = $_REQUEST['step']-1;
			if($_POST['bk']) $stepH -=1;
			print('<form action="'.$_SERVER['PHP_SELF'].'?lang='.$_SESSION['web']['lang'].'&amp;op=install" method="post">');
				print('<div class="head1">'.$lang[$_REQUEST['op']].': '.$lang['istep_'.$stepH].' ['.$stepH.'/4]</div>');
				#wyswietlenie formularzy
				switch($stepH){
					case 1:{
						$back = 1;
						if(!$_POST['server']) $_POST['server'] = 'localhost';
						if(!$_POST['prefix']) $_POST['prefix'] = 'league';
						print('<div class="formH">'.$lang['server'].':</div><input type="text" name="server" value="'.$_POST['server'].'"/><br/>
						<div class="formH">'.$lang['db_login'].':</div><input type="text" name="login" value="'.$_POST['login'].'"/><br/>
						<div class="formH">'.$lang['db_passw'].':</div><input type="password" name="passw" value="'.$_POST['passw'].'"/><br/>
						<div class="formH">'.$lang['dbase'].':</div><input type="text" name="dbase" value="'.$_POST['dbase'].'"/><br/>
						<div class="formH">'.$lang['prefix'].':</div><input type="text" name="prefix" value="'.$_POST['prefix'].'"/><br/>');
						break;
					}
					case 2:{
						$onoff = array('on'=>$lang['auth_mail'], 'off'=>$lang['off']);
						$lnk = opendir('_lang');
						while($dir=readdir($lnk)){
							if($dir!='.' && $dir!='..') $langs[] = substr($dir,0,-4);
						}
						$chmod = array('755'=>$lang['standard'], '777'=>$lang['maximum']);
						$ltype = array('T'=>$lang['team'], 'D'=>$lang['duel']);
						$score = array('M'=>$lang['map_score'], 'R'=>$lang['round_score']);
						$forum = array('-', 'phpBB');
						$yesno = array('0'=>$lang['yes'], '1'=>$lang['no']);
						if(!$_POST['website']) $_POST['website'] = 'http://league.net/';
						if(!$_POST['cookies']) $_POST['cookies'] = 'http://league.net';
						if(!$_POST['website_email']) $_POST['website_email'] = 'league@league.net';
						if(!$_POST['league_web']) $_POST['league_web'] = 'http://league.net/league/';
						print('<div class="head2">'.$lang['global_settings'].'</div>
						<div class="formH">*'.$lang['website'].':</div><input type="text" name="website" value="'.$_POST['website'].'" style="width: 200px;"/><br/>
						<div class="formH">**'.$lang['cookies'].':</div><input type="text" name="cookies" value="'.$_POST['cookies'].'"/><br/>
						<div class="formH">***'.$lang['website_email'].':</div><input type="text" name="website_email" value="'.$_POST['website_email'].'" style="width: 200px;"/><br/>
						<div class="formH">'.$lang['accounts_auth'].':</div><select name="accounts_auth">'.assoc_opt2($onoff,$_POST['accounts_auth']).'</select><br/>
						<div class="formH">****'.$lang['prival'].':</div><select name="prival">'.assoc_opt2($chmod,$_POST['prival']).'</select><br/><br/>
						* - '.$lang['league_web_info'].'<br/>
						** - '.$lang['cookies_info'].'<br/>
						*** - '.$lang['website_email_info'].'<br/>
						**** - '.$lang['prival_info'].'<br/><br/>
						<div class="head2">'.$lang['league_settings'].'</div>
						<div class="formH">'.$lang['default_lang'].':</div><select name="default_lang">'.array_opt2($langs,$_POST['default_lang']).'</select><br/>
						<div class="formH">'.$lang['ltype'].':</div><select name="ltype">'.assoc_opt2($ltype,$_POST['ltype']).'</select><br/>
						<div class="formH">'.$lang['match_score'].':</div><select name="score">'.assoc_opt2($score,$_POST['score']).'</select><br/><br/>
						<div class="head2">'.$lang['forum_settings'].'</div>
						<div class="formH">'.$lang['forum'].':</div><select name="forum">'.array_opt2($forum,$_POST['forum']).'</select><br/>
						<div class="formH">'.$lang['forum_prefix'].':</div><input type="text" name="forum_prefix" value="'.$_POST['forum_prefix'].'" style="width: 200px;"/><br/>
						<div class="formH">'.$lang['forum_web'].':</div><input type="text" name="forum_web" value="'.$_POST['forum_web'].'" style="width: 200px;"/><br/><br/>
						'.$lang['forum_info'].'<br/>
						');
						break;
					}
					case 3:{
						print('<div class="formH">'.$lang['login'].':</div><input type="text" name="na_login" value="'.$_POST['na_login'].'"/><br/>
						<div class="formH">'.$lang['passw'].':</div><input type="password" name="na_passw" value="'.$_POST['na_passw'].'"/><br/>
						<div class="formH">'.$lang['email'].':</div><input type="text" name="na_email" value="'.$_POST['na_email'].'"/><br/>');
						break;
					}
					case 4:{
						print($lang['step4_info'].'<br/><a href="index.php">'.$lang['go_website'].'</a><br/>');
						break;
					}
				}
				print('<br/>');
				if($stepH>1) print('<input type="submit" name="bk" value="&laquo; '.$lang['back'].'"/> <input type="hidden" name="server" value="'.$_POST['server'].'"/><input type="hidden" name="login" value="'.$_POST['login'].'"/><input type="hidden" name="passw" value="'.$_POST['passw'].'"/><input type="hidden" name="dbase" value="'.$_POST['dbase'].'"/><input type="hidden" name="prefix" value="'.$_POST['prefix'].'"/>');
				if($stepH>2) print('<input type="hidden" name="prival" value="'.$_POST['prival'].'"/>');
				if($stepH<4) print('<input type="submit" name="go" value="'.$lang['next'].' &raquo;"/> <input type="submit" name="skip" value="'.$lang['skip'].' &raquo;&raquo;"/>');
			print('<input type="hidden" name="step" value="'.($stepH+1).'"/>
			</form>');
		}else{
			print('<div class="head1">'.$lang[$_REQUEST['op']].'</div>');
			readfile($read);
		}
	}else{
		echo 'start';
	}
?>
</div>
<div id="foot"><a name="ver">installer ver. 0.2</a>, powered by <a href="http://kmleague.net">KMleague</a></div>
</div>

</body>
</html>
