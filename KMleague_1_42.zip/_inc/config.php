<?php
#DataBase data
#define(KML_DB_HOST, 'localhost');
#define(KML_DB_USER, 'root');
#define(KML_DB_PASSW, '');
#define(KML_DB_NAME, 'q2scene');
#website main address
#define(KML_WEBSITE, 'http://kmleague.net/beta/');
#cookie main address
#define(KML_COOKIES, 'kmleague.net/beta');
#maximum avatar size
#define(KML_AVATAR_SIZE, '15360');
#maximum avatar resolution width:height (60:60 as default)
#define(KML_AVATAR_RES, '60:60');
#admin e-mail (ie. shows in mails for new registered users)
#define(KML_ADMIN_MAIL, 'webmaster@kmprojekt.pl');
#authorization of accounts(on, off)
#define(KML_ACCOUNT_AUTH, 'off');
#turn on/off registration
#define(KML_REGISTRATION, 1);
#chmod which allow league script to remove files on server
#define(KML_CHMOD, 0777);
#e-mail address on which all db errors will be sent
#define(KML_ERROR_MAIL, 'cl@epf.pl');
#multi dirs Y-yes,N-no (if you want multi leagues be set up in different dirs set it to Y), no to display leagues list on website and switch through it
#define(KML_MULTI_DIRS, 'N');
#tables prefix
#define(KML_PREFIX, 'league');
#default league id (set 0 if you have default page), use it just if you have KML_MULTI_LEAGUES set N
#define(KML_DEFAULT_LEAGUE, 1);
#number of days to clean password change and accounts before authorization
#define(KML_CLEAN_REG_PAS, 3);
#demosquad linkage(if its not set, scripts will be set as standalone/without DEMOSQUAD demos
#define('DEMOSQUAD','');
?>
