INDEX

1. Author
2. Installation
3. How to Start
4. Project Informations
5. Support, Donations & Contact


1. Author
Krystian "Claymore" Zbikowski claypl@gmail.com


2. Installation
- upload unziped files on server into
- open http://your_website.com and follow the instructions


3. How to Start
* First log in on website and go to admin's panel.
* Edit season (SEASON>EDIT).
- set name whatever you wants
* Edit league (SEASON>LEAGUES).
- set settings which you wants
* Add teams (TEAMS>MANAGE) or let ppl to register their
own teams (CONFIGURATION>USER TEAMS -> YES)

* LEAGUE TYPE

GROUPS
- create GROUPS
- add teams to specify group (GROUPS>ROUND 1)
- add match (NEW MATCH>GROUP PHASE 1>GROUP NAME)
you can also add SCHEDULE first and then EDIT MATCH

PLAY OFFS
- create PLAYOFF TABLE
- Name->whatever
- Teams number->number of teams which participate in that playoff table
- Best place->best place which team can get after win this playoff table
(if you create just one playoff table then choose 1, when u create more
then you need to decide yourself)
- Type->in most cases choose Standard (full let teams/players get specify
place not 3-4 5-8 and so on ..)
- add match
- Round->round which they play
- Position->position in play off tree 1,2,3 ... (choose negativ numbers if
u want to have looser brackets -1,-2,-3
{for the final match choose round->0, position->0})
- Playoff table->choose table in which they play
For more information check website's manual.


4. Project Informations
For more information about project, refer to
http://kmleague.net, or contact author (check below).


5. Support, Donations & Contact
If you want to improve that project you
can contact with author using this ways:

ICQ: 77564235
Gadu-Gadu: 3473357
MSN: clay_pl@hotmail.com
E-mail: claypl@gmail.com

If you using scripts and you want to motivate me
to do some special changes or to keep working on
that project you can donatione my work,
for more information check http://kmleague.net
