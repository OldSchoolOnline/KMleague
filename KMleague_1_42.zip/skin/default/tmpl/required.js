<!--
function smiles(param){
		window.document.forms['new_com'].comment.value = window.document.forms['new_com'].comment.value + ' ' + param
}
function displayWindow(url, width, height) {
		var Win = window.open(url,"displayWindow",'width=' + width + ',height=' + height + ',resizable=0,scrollbars=no,menubar=no');
}
function flip( id ){
	var o = document.getElementById(id);
	if ( o.style.display == "block" )
		o.style.display = "none";
	else
		o.style.display = "block";
}
function dodaj(param){
	window.document.forms['formula'].descr.value = window.document.forms['formula'].descr.value + ' ' + param;
}
function dodaj_flage(param){
	window.document.forms['formula'].descr.value = window.document.forms['formula'].descr.value + ' [LFLAG="' + param + '"]';
}
-->
